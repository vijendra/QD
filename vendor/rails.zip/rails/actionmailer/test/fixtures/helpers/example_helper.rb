module ExampleHelper
  def example_format(text)
    "<em><strong><small>#{text}</small></strong></em>"
  end
end
