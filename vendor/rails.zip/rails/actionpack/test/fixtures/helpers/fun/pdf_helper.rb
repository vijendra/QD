module Fun::PdfHelper
  def foobar() 'baz' end
end
