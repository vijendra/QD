class Mascot < ActiveRecord::Base
  belongs_to :company
end